<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Rank;

class RankController extends Controller
{
    public function index(){
        $data = Rank::all();
        return response()->json( $data );
    }

    public function store(Request $request){
        $rank = Rank::create($request->all());

        return response()->json([
            "message" => "Rank created successfully.",
        ]);
    }

    public function update(Request $request, Rank $rank){
        $rank->update($request->all());
        $rank->refresh();

        return response()->json([
            "message" => "Rank updated successfully."
        ]);
    }

    public function destroy(Rank $rank){
        $rank->delete();

        return response()->json([
            "message" => "Rank deleted successfully."
        ]);
    }
}
