<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Profile;

class ProfileController extends Controller
{
    public function index(){
        $data = Profile::all();
        return response()->json( $data );
    }

    public function store(Request $request){
        $profile = Profile::create($request->all());

        return response()->json([
            "message" => "Profile created successfully.",
        ]);
    }

    public function update(Request $request, Profile $profile){
        $profile->update($request->all());
        $profile->refresh();

        return response()->json([
            "message" => "Profile updated successfully."
        ]);
    }

    public function destroy(Profile $profile){
        $profile->delete();

        return response()->json([
            "message" => "Profile deleted successfully."
        ]);
    }
}
