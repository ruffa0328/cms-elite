<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\ProfileController;
use App\Http\Controllers\API\RankController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register', [RegisterController::class, 'register']);
Route::post('login', [RegisterController::class, 'login']);

Route::group([ 'middlaware' => [ 'auth:api' ] ], function(){

    Route::group([ 'prefix' => 'profile' ], function(){
        Route::get('list', [ProfileController::class, 'index']);
        Route::post('create', [ProfileController::class, 'store']);
        Route::post('update/{profile}', [ProfileController::class, 'update']);
        Route::delete('delete/{profile}', [ProfileController::class, 'destroy']);
    });

    Route::group([ 'prefix' => 'rank' ], function(){
        Route::get('list', [RankController::class, 'index']);
        Route::post('create', [RankController::class, 'store']);
        Route::post('update/{rank}', [RankController::class, 'update']);
        Route::delete('delete/{rank}', [RankController::class, 'destroy']);
    });
});